export default interface ICategoria {
  valor: string;
  label: string;
  emoji: string;
  color: string;
}
