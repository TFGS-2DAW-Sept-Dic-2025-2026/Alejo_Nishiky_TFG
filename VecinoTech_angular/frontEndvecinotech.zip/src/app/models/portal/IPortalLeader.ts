export interface IPortalLeader {
  name: string;
  points: number;
}
