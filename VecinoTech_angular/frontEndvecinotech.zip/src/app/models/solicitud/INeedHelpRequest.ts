/**
 * Request para crear solicitud de ayuda
 */
export interface INeedHelpRequest {
    asunto: string;
    descripcion: string;
    categoria: string;
}
