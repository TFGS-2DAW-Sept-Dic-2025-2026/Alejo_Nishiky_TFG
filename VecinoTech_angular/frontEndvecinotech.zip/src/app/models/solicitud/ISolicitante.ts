export default interface ISolicitante {
  id: number;
  nombre: string;
}
