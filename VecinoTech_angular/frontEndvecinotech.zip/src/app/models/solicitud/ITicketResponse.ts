/**
 * Response del ticket generado al crear solicitud
 */
export interface ITicketResponse {
    ticket: string;
}
