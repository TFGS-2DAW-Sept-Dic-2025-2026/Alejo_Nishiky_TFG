export default interface IUbicacion {
  latitud: number;
  longitud: number;
}
