/**
 * Request para login de usuario
 */
export interface ILoginRequest {
    email: string;
    password: string;
}
