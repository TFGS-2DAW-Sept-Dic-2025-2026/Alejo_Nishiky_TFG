import { HttpInterceptorFn, HttpRequest, HttpHandlerFn, HttpEvent } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, switchMap, throwError, Observable } from 'rxjs';

import { IAuthPayload } from '../models/auth/IAuthPayload';
import { StorageGlobalService } from '../services/storage-global.service';
import { RestClientService } from '../services/rest-cliente.service';
import IRestMessage from '../models/IRestMessage';

export const authInterceptor: HttpInterceptorFn = (
  req: HttpRequest<any>,
  next: HttpHandlerFn
): Observable<HttpEvent<any>> => {
  const storage = inject(StorageGlobalService);
  const router = inject(Router);
  const restCliente = inject(RestClientService);

  const jwts = storage.getJWT(); // { accessToken, refreshToken }

  let authReq = req;

  if (jwts.accessToken) {
    authReq = req.clone({
      setHeaders: { Authorization: `Bearer ${jwts.accessToken}` }
    });
  }

  return next(authReq).pipe(
    catchError(err => {
      console.log('Error capturado en interceptor:', err);
      if (err.status === 401 && jwts.refreshToken) {
        // Intentar refresh
        return restCliente.RefrescarTokens(jwts.refreshToken).pipe(
          switchMap((resp: IRestMessage) => {
            if (resp.codigo === 0 && resp.datos) {
              const payload = resp.datos as IAuthPayload;
              storage.setSession(payload);

              const retry = req.clone({
                setHeaders: { Authorization: `Bearer ${payload.accessToken}` }
              });
              return next(retry);
            } else {
              storage.clearSession();
              router.navigate(['/usuario/login']);
              return throwError(() => new Error('Fallo en refresh token'));
            }
          }),
          catchError(refreshErr => {
            storage.clearSession();
            router.navigate(['/usuario/login']);
            return throwError( () => refreshErr);
          })
        );
      }
      return throwError(() => err);
    })
  );
};
