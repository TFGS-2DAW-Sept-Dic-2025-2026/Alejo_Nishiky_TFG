// Polyfill para sockjs-client
(window as any).global = window;
